"use client"

import type React from "react"

import { useState } from "react"
import Link from "next/link"
import { SearchIcon } from "lucide-react"
import ProductCard from "@/components/product-card"

export default function SearchPage() {
  const [query, setQuery] = useState("")
  const [searchResults, setSearchResults] = useState<any[]>([])
  const [hasSearched, setHasSearched] = useState(false)

  const allProducts = [
    { id: "1", name: "Ultra Soft Crewneck T-Shirt", price: 19.9, category: "Men", rating: 4.8 },
    { id: "2", name: "Heattech Base Layer", price: 29.9, category: "Men", rating: 4.9 },
    { id: "3", name: "Rayon Long-Sleeve Shirt", price: 34.9, category: "Women", rating: 4.7 },
    { id: "4", name: "Cotton Linen Blend Pants", price: 49.9, category: "Women", rating: 4.6 },
    { id: "5", name: "Kids Lightweight Down Jacket", price: 59.9, category: "Kids", rating: 4.8 },
    { id: "6", name: "AIRism Cotton Shorts", price: 24.9, category: "Men", rating: 4.7 },
    { id: "7", name: "Wool Blend Sweater", price: 39.9, category: "Women", rating: 4.9 },
    { id: "8", name: "Seamless Layering Tank", price: 14.9, category: "Women", rating: 4.6 },
  ]

  const handleSearch = (e: React.FormEvent) => {
    e.preventDefault()
    setHasSearched(true)

    const results = allProducts.filter(
      (p) =>
        p.name.toLowerCase().includes(query.toLowerCase()) || p.category.toLowerCase().includes(query.toLowerCase()),
    )

    setSearchResults(results)
  }

  return (
    <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
      <h1 className="text-4xl font-bold mb-8">Search Products</h1>

      <form onSubmit={handleSearch} className="mb-12">
        <div className="relative">
          <input
            type="text"
            value={query}
            onChange={(e) => setQuery(e.target.value)}
            placeholder="Search for products, categories, or styles..."
            className="w-full px-4 py-4 border-2 border-foreground rounded-lg text-lg focus:outline-none focus:ring-2 focus:ring-accent"
          />
          <button type="submit" className="absolute right-4 top-1/2 transform -translate-y-1/2 text-foreground">
            <SearchIcon size={24} />
          </button>
        </div>
      </form>

      {hasSearched && (
        <div>
          {searchResults.length > 0 ? (
            <div>
              <p className="text-sm text-muted-foreground mb-6">
                Found {searchResults.length} results for "{query}"
              </p>
              <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-6">
                {searchResults.map((product) => (
                  <ProductCard
                    key={product.id}
                    id={product.id}
                    name={product.name}
                    price={product.price}
                    image={`/placeholder.svg?height=400&width=400&query=${product.name.replace(/ /g, "%20")}`}
                    category={product.category}
                    rating={product.rating}
                  />
                ))}
              </div>
            </div>
          ) : (
            <div className="text-center py-12">
              <p className="text-xl text-muted-foreground mb-4">No products found matching "{query}"</p>
              <Link href="/shop" className="text-accent hover:underline font-medium">
                Browse all products
              </Link>
            </div>
          )}
        </div>
      )}

      {!hasSearched && (
        <div className="space-y-8">
          <div>
            <h2 className="text-2xl font-bold mb-4">Popular Searches</h2>
            <div className="flex flex-wrap gap-3">
              {["T-Shirts", "Jeans", "Sweaters", "Jackets", "Underwear", "Pants"].map((term) => (
                <button
                  key={term}
                  onClick={() => {
                    setQuery(term)
                    handleSearch({ preventDefault: () => {} } as React.FormEvent)
                  }}
                  className="px-4 py-2 border border-border rounded hover:border-foreground transition"
                >
                  {term}
                </button>
              ))}
            </div>
          </div>

          <div>
            <h2 className="text-2xl font-bold mb-4">Browse Categories</h2>
            <div className="grid grid-cols-1 sm:grid-cols-3 gap-4">
              {[
                { name: "Men", link: "/men" },
                { name: "Women", link: "/women" },
                { name: "Kids", link: "/kids" },
              ].map((cat) => (
                <Link
                  key={cat.name}
                  href={cat.link}
                  className="p-6 bg-secondary rounded border border-border hover:border-foreground transition text-center font-bold"
                >
                  {cat.name}
                </Link>
              ))}
            </div>
          </div>
        </div>
      )}
    </div>
  )
}
