"use client"

import { useState, useEffect } from "react"
import Link from "next/link"
import ProductCard from "@/components/product-card"
import { ChevronRight, Zap, Leaf, Heart } from "lucide-react"

export default function HomePage() {
  const [products, setProducts] = useState<Array<any>>([])

  useEffect(() => {
    // Mock featured products
    setProducts([
      {
        id: "1",
        name: "Ultra Soft Crewneck T-Shirt",
        price: 19.9,
        image: "/uniqlo-mens-tshirt.jpg",
        category: "Men",
        rating: 4.8,
      },
      {
        id: "2",
        name: "Heattech Base Layer",
        price: 29.9,
        image: "/uniqlo-heattech-mens.jpg",
        category: "Men",
        rating: 4.9,
      },
      {
        id: "3",
        name: "Rayon Long-Sleeve Shirt",
        price: 34.9,
        image: "/uniqlo-womens-shirt.jpg",
        category: "Women",
        rating: 4.7,
      },
      {
        id: "4",
        name: "Cotton Linen Blend Pants",
        price: 49.9,
        image: "/uniqlo-womens-pants.jpg",
        category: "Women",
        rating: 4.6,
      },
      {
        id: "5",
        name: "Kids Lightweight Down Jacket",
        price: 59.9,
        image: "/uniqlo-kids-jacket.jpg",
        category: "Kids",
        rating: 4.8,
      },
      {
        id: "6",
        name: "AIRism Cotton Shorts",
        price: 24.9,
        image: "/uniqlo-mens-shorts.jpg",
        category: "Men",
        rating: 4.7,
      },
      {
        id: "7",
        name: "Wool Blend Sweater",
        price: 39.9,
        image: "/uniqlo-womens-sweater.jpg",
        category: "Women",
        rating: 4.9,
      },
      {
        id: "8",
        name: "Seamless Layering Tank",
        price: 14.9,
        image: "/uniqlo-womens-tank-top.jpg",
        category: "Women",
        rating: 4.6,
      },
    ])
  }, [])

  return (
    <div>
      {/* Hero Section */}
      <section className="relative h-96 md:h-[500px] overflow-hidden bg-gradient-to-r from-secondary to-muted flex items-center">
        <div className="absolute inset-0">
          <img src="/premium-lifestyle-fashion-minimal.jpg" alt="Hero Banner" className="w-full h-full object-cover opacity-40" />
        </div>
        <div className="relative z-10 max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 w-full">
          <div className="max-w-md">
            <h1 className="text-5xl md:text-6xl font-bold mb-4 text-foreground">
              Fashion for <span className="text-accent">Everyone</span>
            </h1>
            <p className="text-lg text-foreground/80 mb-6">Discover quality basics for everyday living</p>
            <Link
              href="/new"
              className="inline-flex items-center gap-2 bg-accent hover:bg-accent/90 text-accent-foreground px-6 py-3 font-medium rounded transition"
            >
              Shop New Arrivals
              <ChevronRight size={20} />
            </Link>
          </div>
        </div>
      </section>

      {/* Features Section */}
      <section className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-16">
        <div className="grid grid-cols-1 md:grid-cols-3 gap-8">
          <div className="flex flex-col items-center text-center">
            <div className="bg-secondary p-4 rounded-full mb-4">
              <Zap className="text-accent" size={28} />
            </div>
            <h3 className="font-bold text-lg mb-2">Premium Quality</h3>
            <p className="text-sm text-muted-foreground">
              Carefully designed and manufactured for comfort and durability
            </p>
          </div>
          <div className="flex flex-col items-center text-center">
            <div className="bg-secondary p-4 rounded-full mb-4">
              <Leaf className="text-accent" size={28} />
            </div>
            <h3 className="font-bold text-lg mb-2">Sustainable</h3>
            <p className="text-sm text-muted-foreground">Made with eco-friendly materials and responsible practices</p>
          </div>
          <div className="flex flex-col items-center text-center">
            <div className="bg-secondary p-4 rounded-full mb-4">
              <Heart className="text-accent" size={28} />
            </div>
            <h3 className="font-bold text-lg mb-2">Style Essential</h3>
            <p className="text-sm text-muted-foreground">Timeless designs that work for every occasion</p>
          </div>
        </div>
      </section>

      {/* Featured Products */}
      <section className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-16 border-t border-border">
        <div className="flex items-center justify-between mb-8">
          <h2 className="text-3xl font-bold">Featured Products</h2>
          <Link href="/shop" className="flex items-center gap-1 text-accent hover:underline font-medium">
            View All
            <ChevronRight size={20} />
          </Link>
        </div>
        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-6">
          {products.map((product) => (
            <ProductCard
              key={product.id}
              id={product.id}
              name={product.name}
              price={product.price}
              image={product.image}
              category={product.category}
              rating={product.rating}
            />
          ))}
        </div>
      </section>

      {/* Categories Section */}
      <section className="bg-secondary py-16 border-t border-border">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <h2 className="text-3xl font-bold mb-8">Shop by Category</h2>
          <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
            {[
              { name: "Men", link: "/men", image: "/mens-fashion-casual.jpg" },
              { name: "Women", link: "/women", image: "/womens-fashion-casual.jpg" },
              { name: "Kids", link: "/kids", image: "/kids-fashion-casual.jpg" },
            ].map((category) => (
              <Link key={category.name} href={category.link} className="group relative overflow-hidden rounded h-64">
                <img
                  src={category.image || "/placeholder.svg"}
                  alt={category.name}
                  className="w-full h-full object-cover group-hover:scale-105 transition duration-300"
                />
                <div className="absolute inset-0 bg-black/20 group-hover:bg-black/40 transition flex items-center justify-center">
                  <h3 className="text-white text-2xl font-bold">{category.name}</h3>
                </div>
              </Link>
            ))}
          </div>
        </div>
      </section>

      {/* Promotion Banner */}
      <section className="bg-accent text-accent-foreground py-8">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 text-center">
          <h2 className="text-2xl md:text-3xl font-bold mb-2">Special Offer</h2>
          <p className="text-lg mb-4">Get 20% off on your first purchase with code: WELCOME20</p>
          <Link
            href="/shop"
            className="inline-flex items-center gap-2 bg-accent-foreground text-accent px-6 py-3 font-medium rounded hover:opacity-90 transition"
          >
            Shop Now
          </Link>
        </div>
      </section>
    </div>
  )
}
