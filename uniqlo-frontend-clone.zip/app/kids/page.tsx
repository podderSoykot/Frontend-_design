"use client"

import { useState } from "react"
import ProductCard from "@/components/product-card"

export default function KidsPage() {
  const [selectedAge, setSelectedAge] = useState<string | null>(null)

  const kidsProducts = [
    { id: "1", name: "Kids Lightweight Down Jacket", price: 59.9, ageGroup: "6-8", rating: 4.8 },
    { id: "2", name: "Merino Wool Socks", price: 9.9, ageGroup: "All Ages", rating: 4.5 },
    { id: "3", name: "Graphic T-Shirt", price: 14.9, ageGroup: "4-6", rating: 4.6 },
    { id: "4", name: "Fleece Hoodie", price: 34.9, ageGroup: "8-10", rating: 4.7 },
    { id: "5", name: "Cotton Shorts", price: 19.9, ageGroup: "6-8", rating: 4.5 },
    { id: "6", name: "Waterproof Rain Jacket", price: 49.9, ageGroup: "10+", rating: 4.8 },
    { id: "7", name: "Cozy Pajama Set", price: 24.9, ageGroup: "4-6", rating: 4.9 },
    { id: "8", name: "Durable Play Pants", price: 29.9, ageGroup: "8-10", rating: 4.7 },
  ]

  const filteredProducts = selectedAge ? kidsProducts.filter((p) => p.ageGroup === selectedAge) : kidsProducts

  return (
    <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
      <h1 className="text-4xl font-bold mb-8">Kids Collection</h1>

      <div className="grid grid-cols-1 lg:grid-cols-4 gap-8">
        {/* Age Filter */}
        <aside className="lg:col-span-1">
          <div className="mb-8">
            <h3 className="font-bold text-lg mb-4">Age Group</h3>
            <div className="space-y-2">
              <button
                onClick={() => setSelectedAge(null)}
                className={`w-full text-left px-4 py-2 rounded transition ${
                  selectedAge === null ? "bg-accent text-accent-foreground font-medium" : "hover:bg-secondary"
                }`}
              >
                All Kids
              </button>
              {["4-6", "6-8", "8-10", "10+", "All Ages"].map((age) => (
                <button
                  key={age}
                  onClick={() => setSelectedAge(age)}
                  className={`w-full text-left px-4 py-2 rounded transition ${
                    selectedAge === age ? "bg-accent text-accent-foreground font-medium" : "hover:bg-secondary"
                  }`}
                >
                  {age}
                </button>
              ))}
            </div>
          </div>
        </aside>

        {/* Products Grid */}
        <main className="lg:col-span-3">
          <p className="text-sm text-muted-foreground mb-6">Showing {filteredProducts.length} products</p>
          <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-6">
            {filteredProducts.map((product) => (
              <ProductCard
                key={product.id}
                id={product.id}
                name={product.name}
                price={product.price}
                image={`/placeholder.svg?height=400&width=400&query=kids%20${product.name.replace(/ /g, "%20")}`}
                category="Kids"
                rating={product.rating}
              />
            ))}
          </div>
        </main>
      </div>
    </div>
  )
}
