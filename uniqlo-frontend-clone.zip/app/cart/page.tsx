"use client"

import { useState } from "react"
import Link from "next/link"
import { X, Plus, Minus } from "lucide-react"

export default function CartPage() {
  const [cartItems, setCartItems] = useState([
    {
      id: "1",
      name: "Premium Crewneck T-Shirt",
      price: 29.9,
      quantity: 2,
      size: "M",
      color: "Black",
      image: "/plain-white-tshirt.png",
    },
    {
      id: "2",
      name: "Cotton Linen Blend Pants",
      price: 49.9,
      quantity: 1,
      size: "32",
      color: "Navy",
      image: "/various-styles-of-pants.png",
    },
  ])

  const updateQuantity = (id: string, newQuantity: number) => {
    if (newQuantity <= 0) return
    setCartItems(cartItems.map((item) => (item.id === id ? { ...item, quantity: newQuantity } : item)))
  }

  const removeItem = (id: string) => {
    setCartItems(cartItems.filter((item) => item.id !== id))
  }

  const subtotal = cartItems.reduce((sum, item) => sum + item.price * item.quantity, 0)
  const shipping = subtotal > 100 ? 0 : 10
  const tax = subtotal * 0.08
  const total = subtotal + shipping + tax

  return (
    <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
      <h1 className="text-3xl font-bold mb-8">Shopping Cart</h1>

      {cartItems.length === 0 ? (
        <div className="text-center py-16">
          <p className="text-xl text-muted-foreground mb-4">Your cart is empty</p>
          <Link
            href="/shop"
            className="inline-block bg-primary text-primary-foreground px-6 py-3 rounded font-medium hover:opacity-90 transition"
          >
            Continue Shopping
          </Link>
        </div>
      ) : (
        <div className="grid grid-cols-1 lg:grid-cols-3 gap-8">
          {/* Cart Items */}
          <div className="lg:col-span-2 space-y-4">
            {cartItems.map((item) => (
              <div key={item.id} className="flex gap-4 p-4 bg-secondary rounded border border-border">
                <img
                  src={item.image || "/placeholder.svg"}
                  alt={item.name}
                  className="w-24 h-24 object-cover rounded bg-background"
                />
                <div className="flex-1">
                  <h3 className="font-bold">{item.name}</h3>
                  <p className="text-sm text-muted-foreground mb-2">
                    {item.color} - Size {item.size}
                  </p>
                  <p className="font-bold text-lg">${item.price}</p>
                </div>
                <div className="flex flex-col items-end justify-between">
                  <button
                    onClick={() => removeItem(item.id)}
                    className="text-muted-foreground hover:text-foreground transition"
                  >
                    <X size={20} />
                  </button>
                  <div className="flex items-center border border-border rounded">
                    <button
                      onClick={() => updateQuantity(item.id, item.quantity - 1)}
                      className="px-2 py-1 hover:bg-muted transition"
                    >
                      <Minus size={16} />
                    </button>
                    <span className="px-3 py-1 border-l border-r border-border">{item.quantity}</span>
                    <button
                      onClick={() => updateQuantity(item.id, item.quantity + 1)}
                      className="px-2 py-1 hover:bg-muted transition"
                    >
                      <Plus size={16} />
                    </button>
                  </div>
                </div>
              </div>
            ))}
          </div>

          {/* Order Summary */}
          <div className="lg:col-span-1">
            <div className="bg-secondary p-6 rounded border border-border sticky top-20 space-y-4">
              <h2 className="text-xl font-bold">Order Summary</h2>

              <div className="space-y-3 border-b border-border pb-4">
                <div className="flex justify-between text-sm">
                  <span>Subtotal</span>
                  <span>${subtotal.toFixed(2)}</span>
                </div>
                <div className="flex justify-between text-sm">
                  <span>Shipping</span>
                  <span>{shipping === 0 ? "FREE" : `$${shipping.toFixed(2)}`}</span>
                </div>
                <div className="flex justify-between text-sm">
                  <span>Tax</span>
                  <span>${tax.toFixed(2)}</span>
                </div>
              </div>

              <div className="flex justify-between text-lg font-bold">
                <span>Total</span>
                <span>${total.toFixed(2)}</span>
              </div>

              {subtotal <= 100 && (
                <p className="text-xs text-muted-foreground text-center bg-background p-2 rounded">
                  Free shipping on orders over $100
                </p>
              )}

              <Link
                href="/checkout"
                className="w-full block text-center bg-primary text-primary-foreground py-3 rounded font-bold hover:opacity-90 transition"
              >
                Proceed to Checkout
              </Link>

              <Link
                href="/shop"
                className="w-full block text-center border-2 border-foreground py-3 rounded font-medium hover:bg-secondary transition"
              >
                Continue Shopping
              </Link>

              <details className="text-sm text-muted-foreground pt-2 border-t border-border">
                <summary className="cursor-pointer font-medium text-foreground">Promo Code</summary>
                <div className="mt-3 space-y-2">
                  <input
                    type="text"
                    placeholder="Enter promo code"
                    className="w-full px-3 py-2 border border-input rounded text-foreground"
                  />
                  <button className="w-full bg-foreground text-background py-2 rounded font-medium hover:opacity-90 transition">
                    Apply
                  </button>
                </div>
              </details>
            </div>
          </div>
        </div>
      )}
    </div>
  )
}
