"use client"

import ProductCard from "@/components/product-card"

export default function NewArrivalsPage() {
  const newProducts = [
    { id: "1", name: "Premium Crewneck T-Shirt", price: 29.9, category: "Men", rating: 4.8, isNew: true },
    { id: "2", name: "Heattech Base Layer", price: 29.9, category: "Men", rating: 4.9, isNew: true },
    { id: "3", name: "Rayon Long-Sleeve Shirt", price: 34.9, category: "Women", rating: 4.7, isNew: true },
    { id: "4", name: "Cotton Linen Blend Pants", price: 49.9, category: "Women", rating: 4.6, isNew: true },
    { id: "5", name: "Kids Lightweight Down Jacket", price: 59.9, category: "Kids", rating: 4.8, isNew: true },
    { id: "6", name: "AIRism Cotton Shorts", price: 24.9, category: "Men", rating: 4.7, isNew: true },
    { id: "7", name: "Wool Blend Sweater", price: 39.9, category: "Women", rating: 4.9, isNew: true },
    { id: "8", name: "Seamless Layering Tank", price: 14.9, category: "Women", rating: 4.6, isNew: true },
  ]

  return (
    <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
      <h1 className="text-4xl font-bold mb-8">New Arrivals</h1>
      <p className="text-lg text-muted-foreground mb-8">Discover our latest collection of premium clothing</p>

      <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-6">
        {newProducts.map((product) => (
          <ProductCard
            key={product.id}
            id={product.id}
            name={product.name}
            price={product.price}
            image={`/placeholder.svg?height=400&width=400&query=new%20${product.name.replace(/ /g, "%20")}`}
            category={product.category}
            rating={product.rating}
          />
        ))}
      </div>
    </div>
  )
}
