"use client"

import { useState } from "react"
import ProductCard from "@/components/product-card"

export default function MenPage() {
  const [selectedSubcategory, setSelectedSubcategory] = useState<string | null>(null)

  const menProducts = [
    { id: "1", name: "Ultra Soft Crewneck T-Shirt", price: 19.9, subcategory: "Tops", rating: 4.8 },
    { id: "2", name: "Heattech Base Layer", price: 29.9, subcategory: "Underwear", rating: 4.9 },
    { id: "3", name: "Stretch Denim Jeans", price: 59.9, subcategory: "Bottoms", rating: 4.8 },
    { id: "4", name: "AIRism Cotton Shorts", price: 24.9, subcategory: "Bottoms", rating: 4.7 },
    { id: "5", name: "Lightweight Puffer Jacket", price: 79.9, subcategory: "Outerwear", rating: 4.9 },
    { id: "6", name: "Oxford Button-Up Shirt", price: 44.9, subcategory: "Tops", rating: 4.6 },
    { id: "7", name: "Wool Sweater", price: 54.9, subcategory: "Tops", rating: 4.8 },
    { id: "8", name: "Chino Pants", price: 49.9, subcategory: "Bottoms", rating: 4.7 },
  ]

  const filteredProducts = selectedSubcategory
    ? menProducts.filter((p) => p.subcategory === selectedSubcategory)
    : menProducts

  return (
    <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
      <h1 className="text-4xl font-bold mb-8">Men's Collection</h1>

      <div className="grid grid-cols-1 lg:grid-cols-4 gap-8">
        {/* Subcategory Filter */}
        <aside className="lg:col-span-1">
          <div className="mb-8">
            <h3 className="font-bold text-lg mb-4">Subcategories</h3>
            <div className="space-y-2">
              <button
                onClick={() => setSelectedSubcategory(null)}
                className={`w-full text-left px-4 py-2 rounded transition ${
                  selectedSubcategory === null ? "bg-accent text-accent-foreground font-medium" : "hover:bg-secondary"
                }`}
              >
                All Items
              </button>
              {["Tops", "Bottoms", "Underwear", "Outerwear"].map((cat) => (
                <button
                  key={cat}
                  onClick={() => setSelectedSubcategory(cat)}
                  className={`w-full text-left px-4 py-2 rounded transition ${
                    selectedSubcategory === cat ? "bg-accent text-accent-foreground font-medium" : "hover:bg-secondary"
                  }`}
                >
                  {cat}
                </button>
              ))}
            </div>
          </div>
        </aside>

        {/* Products Grid */}
        <main className="lg:col-span-3">
          <p className="text-sm text-muted-foreground mb-6">Showing {filteredProducts.length} products</p>
          <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-6">
            {filteredProducts.map((product) => (
              <ProductCard
                key={product.id}
                id={product.id}
                name={product.name}
                price={product.price}
                image={`/placeholder.svg?height=400&width=400&query=mens%20${product.name.replace(/ /g, "%20")}`}
                category="Men"
                rating={product.rating}
              />
            ))}
          </div>
        </main>
      </div>
    </div>
  )
}
