import Link from "next/link"

interface ProductCardProps {
  id: string
  name: string
  price: number
  image: string
  category: string
  rating?: number
}

export default function ProductCard({ id, name, price, image, category, rating }: ProductCardProps) {
  return (
    <Link href={`/product/${id}`}>
      <div className="group cursor-pointer">
        <div className="relative overflow-hidden bg-secondary mb-3 aspect-square">
          <img
            src={image || "/placeholder.svg"}
            alt={name}
            className="w-full h-full object-cover group-hover:scale-105 transition duration-300"
          />
          <div className="absolute top-3 right-3 bg-accent text-accent-foreground px-2 py-1 text-xs font-medium rounded">
            New
          </div>
        </div>
        <div className="space-y-1">
          <p className="text-xs text-muted-foreground">{category}</p>
          <h3 className="text-sm font-medium line-clamp-2 group-hover:text-accent transition">{name}</h3>
          <div className="flex items-center justify-between">
            <p className="text-base font-bold">${price.toFixed(2)}</p>
            {rating && (
              <div className="flex items-center gap-1">
                <span className="text-xs text-muted-foreground">★ {rating}</span>
              </div>
            )}
          </div>
        </div>
      </div>
    </Link>
  )
}
