"use client"

import { useState } from "react"
import Link from "next/link"
import { LogOut, User, ShoppingBag, Heart, Settings } from "lucide-react"

export default function AccountPage() {
  const [isLoggedIn, setIsLoggedIn] = useState(false)
  const [activeTab, setActiveTab] = useState<"profile" | "orders" | "wishlist" | "settings">("profile")

  const userProfile = {
    name: "John Doe",
    email: "john@example.com",
    phone: "+1 (555) 123-4567",
    joinedDate: "2023-01-15",
  }

  const orders = [
    {
      id: "ORD-001",
      date: "2024-12-15",
      items: 3,
      total: 129.8,
      status: "Delivered",
      image: "/order-items-1.jpg",
    },
    {
      id: "ORD-002",
      date: "2024-11-30",
      items: 2,
      total: 79.9,
      status: "Shipped",
      image: "/order-items-2.jpg",
    },
    {
      id: "ORD-003",
      date: "2024-11-15",
      items: 1,
      total: 49.9,
      status: "Delivered",
      image: "/order-items-3.jpg",
    },
  ]

  const wishlist = [
    { id: "1", name: "Heattech Base Layer", price: 29.9 },
    { id: "2", name: "Wool Blend Sweater", price: 39.9 },
    { id: "3", name: "Cotton Linen Blend Pants", price: 49.9 },
  ]

  if (!isLoggedIn) {
    return (
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-16">
        <div className="max-w-md mx-auto text-center">
          <h1 className="text-3xl font-bold mb-4">Welcome Back</h1>
          <p className="text-muted-foreground mb-8">Sign in to your account to view orders and manage preferences</p>

          <div className="space-y-4">
            <div>
              <input
                type="email"
                placeholder="Email"
                className="w-full px-4 py-3 border border-input rounded bg-secondary"
              />
            </div>
            <div>
              <input
                type="password"
                placeholder="Password"
                className="w-full px-4 py-3 border border-input rounded bg-secondary"
              />
            </div>
            <button
              onClick={() => setIsLoggedIn(true)}
              className="w-full bg-primary text-primary-foreground py-3 rounded font-bold hover:opacity-90 transition"
            >
              Sign In
            </button>
            <div className="relative">
              <div className="absolute inset-0 flex items-center">
                <div className="w-full border-t border-border" />
              </div>
              <div className="relative flex justify-center text-sm">
                <span className="px-2 bg-background text-muted-foreground">or</span>
              </div>
            </div>
            <button className="w-full border-2 border-foreground py-3 rounded font-medium hover:bg-secondary transition">
              Create Account
            </button>
          </div>

          <p className="mt-8 text-sm text-muted-foreground">
            <Link href="#" className="text-accent hover:underline">
              Forgot your password?
            </Link>
          </p>
        </div>
      </div>
    )
  }

  return (
    <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
      <div className="flex justify-between items-center mb-8">
        <h1 className="text-3xl font-bold">My Account</h1>
        <button
          onClick={() => setIsLoggedIn(false)}
          className="flex items-center gap-2 text-muted-foreground hover:text-foreground transition"
        >
          <LogOut size={20} />
          Sign Out
        </button>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-4 gap-8">
        {/* Sidebar Navigation */}
        <aside className="lg:col-span-1">
          <nav className="space-y-2">
            {[
              { id: "profile", label: "Profile", icon: User },
              { id: "orders", label: "Orders", icon: ShoppingBag },
              { id: "wishlist", label: "Wishlist", icon: Heart },
              { id: "settings", label: "Settings", icon: Settings },
            ].map(({ id, label, icon: Icon }) => (
              <button
                key={id}
                onClick={() => setActiveTab(id as typeof activeTab)}
                className={`w-full flex items-center gap-3 px-4 py-3 rounded transition ${
                  activeTab === id ? "bg-accent text-accent-foreground font-medium" : "hover:bg-secondary"
                }`}
              >
                <Icon size={20} />
                {label}
              </button>
            ))}
          </nav>
        </aside>

        {/* Content Area */}
        <main className="lg:col-span-3">
          {/* Profile Tab */}
          {activeTab === "profile" && (
            <div className="space-y-6">
              <h2 className="text-2xl font-bold">Profile Information</h2>
              <div className="bg-secondary p-6 rounded border border-border space-y-4">
                <div>
                  <label className="text-sm text-muted-foreground">Name</label>
                  <p className="text-lg font-medium">{userProfile.name}</p>
                </div>
                <div>
                  <label className="text-sm text-muted-foreground">Email</label>
                  <p className="text-lg font-medium">{userProfile.email}</p>
                </div>
                <div>
                  <label className="text-sm text-muted-foreground">Phone</label>
                  <p className="text-lg font-medium">{userProfile.phone}</p>
                </div>
                <div>
                  <label className="text-sm text-muted-foreground">Member Since</label>
                  <p className="text-lg font-medium">{new Date(userProfile.joinedDate).toLocaleDateString()}</p>
                </div>
                <button className="mt-4 bg-primary text-primary-foreground px-6 py-2 rounded font-medium hover:opacity-90 transition">
                  Edit Profile
                </button>
              </div>
            </div>
          )}

          {/* Orders Tab */}
          {activeTab === "orders" && (
            <div className="space-y-6">
              <h2 className="text-2xl font-bold">Order History</h2>
              <div className="space-y-4">
                {orders.map((order) => (
                  <div key={order.id} className="bg-secondary p-6 rounded border border-border flex items-center gap-4">
                    <img
                      src={order.image || "/placeholder.svg"}
                      alt="Order"
                      className="w-20 h-20 object-cover rounded bg-background"
                    />
                    <div className="flex-1">
                      <p className="font-bold">{order.id}</p>
                      <p className="text-sm text-muted-foreground">{new Date(order.date).toLocaleDateString()}</p>
                      <p className="text-sm text-muted-foreground">{order.items} items</p>
                    </div>
                    <div className="text-right">
                      <p className="font-bold">${order.total}</p>
                      <p
                        className={`text-sm font-medium ${order.status === "Delivered" ? "text-green-600" : "text-blue-600"}`}
                      >
                        {order.status}
                      </p>
                    </div>
                    <button className="px-4 py-2 border border-foreground rounded hover:bg-background transition font-medium">
                      View Details
                    </button>
                  </div>
                ))}
              </div>
            </div>
          )}

          {/* Wishlist Tab */}
          {activeTab === "wishlist" && (
            <div className="space-y-6">
              <h2 className="text-2xl font-bold">Wishlist</h2>
              <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                {wishlist.map((item) => (
                  <div key={item.id} className="bg-secondary p-4 rounded border border-border">
                    <p className="font-medium mb-2">{item.name}</p>
                    <p className="text-lg font-bold mb-4">${item.price}</p>
                    <div className="flex gap-2">
                      <button className="flex-1 bg-primary text-primary-foreground py-2 rounded font-medium hover:opacity-90 transition">
                        Add to Cart
                      </button>
                      <button className="px-4 py-2 border border-foreground rounded hover:bg-background transition">
                        ✕
                      </button>
                    </div>
                  </div>
                ))}
              </div>
            </div>
          )}

          {/* Settings Tab */}
          {activeTab === "settings" && (
            <div className="space-y-6">
              <h2 className="text-2xl font-bold">Account Settings</h2>
              <div className="space-y-4">
                <div className="bg-secondary p-6 rounded border border-border">
                  <h3 className="font-bold mb-4">Email Preferences</h3>
                  <label className="flex items-center gap-3 cursor-pointer mb-3">
                    <input type="checkbox" defaultChecked className="w-4 h-4" />
                    <span>Receive promotional emails</span>
                  </label>
                  <label className="flex items-center gap-3 cursor-pointer mb-3">
                    <input type="checkbox" defaultChecked className="w-4 h-4" />
                    <span>Receive order updates</span>
                  </label>
                  <label className="flex items-center gap-3 cursor-pointer">
                    <input type="checkbox" className="w-4 h-4" />
                    <span>Receive new product announcements</span>
                  </label>
                </div>

                <div className="bg-secondary p-6 rounded border border-border">
                  <h3 className="font-bold mb-4">Password</h3>
                  <button className="px-6 py-2 border border-foreground rounded hover:bg-background transition font-medium">
                    Change Password
                  </button>
                </div>

                <div className="bg-secondary p-6 rounded border border-border">
                  <h3 className="font-bold mb-4 text-red-600">Danger Zone</h3>
                  <button className="px-6 py-2 bg-red-600 text-white rounded hover:opacity-90 transition font-medium">
                    Delete Account
                  </button>
                </div>
              </div>
            </div>
          )}
        </main>
      </div>
    </div>
  )
}
