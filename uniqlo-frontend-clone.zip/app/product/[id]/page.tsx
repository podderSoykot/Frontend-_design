"use client"

import { useState } from "react"
import Link from "next/link"
import { Star, Heart, Share2, ChevronRight } from "lucide-react"

export default function ProductPage({ params }: { params: { id: string } }) {
  const [quantity, setQuantity] = useState(1)
  const [selectedSize, setSelectedSize] = useState("M")
  const [selectedColor, setSelectedColor] = useState("Black")
  const [addedToCart, setAddedToCart] = useState(false)

  // Mock product data
  const product = {
    id: params.id,
    name: "Premium Crewneck T-Shirt",
    price: 29.9,
    originalPrice: 39.9,
    rating: 4.8,
    reviews: 234,
    category: "Men",
    description:
      "Experience ultimate comfort with our premium crewneck t-shirt. Made from 100% cotton with a soft, breathable feel, this versatile piece is perfect for everyday wear. The reinforced seams and durable fabric ensure long-lasting quality.",
    sizes: ["XS", "S", "M", "L", "XL", "XXL"],
    colors: ["Black", "White", "Navy", "Gray", "Beige"],
    images: ["/mens-premium-tshirt-black-front.jpg", "/mens-premium-tshirt-black-back.jpg", "/mens-premium-tshirt-detail.jpg"],
    highlights: [
      "100% Soft Cotton",
      "Breathable & Comfortable",
      "Durable Reinforced Seams",
      "Machine Washable",
      "Available in Multiple Colors",
    ],
    specifications: {
      material: "100% Cotton",
      care: "Machine wash cold",
      origin: "Made in Vietnam",
      fit: "Regular Fit",
    },
  }

  const handleAddToCart = () => {
    setAddedToCart(true)
    setTimeout(() => setAddedToCart(false), 2000)
  }

  return (
    <div>
      {/* Breadcrumb */}
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-4 flex items-center gap-2 text-sm text-muted-foreground">
        <Link href="/" className="hover:text-foreground transition">
          Home
        </Link>
        <ChevronRight size={16} />
        <Link href="/shop" className="hover:text-foreground transition">
          Shop
        </Link>
        <ChevronRight size={16} />
        <span className="text-foreground font-medium">{product.name}</span>
      </div>

      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
        <div className="grid grid-cols-1 md:grid-cols-2 gap-8 mb-16">
          {/* Image Gallery */}
          <div>
            <div className="bg-secondary mb-4 aspect-square overflow-hidden rounded">
              <img
                src={product.images[0] || "/placeholder.svg"}
                alt={product.name}
                className="w-full h-full object-cover hover:scale-105 transition duration-300"
              />
            </div>
            <div className="grid grid-cols-3 gap-4">
              {product.images.map((img, idx) => (
                <div
                  key={idx}
                  className="bg-secondary aspect-square overflow-hidden rounded cursor-pointer hover:opacity-70 transition"
                >
                  <img src={img || "/placeholder.svg"} alt={`View ${idx + 1}`} className="w-full h-full object-cover" />
                </div>
              ))}
            </div>
          </div>

          {/* Product Details */}
          <div>
            <div className="mb-4">
              <p className="text-sm text-muted-foreground mb-2">{product.category}</p>
              <h1 className="text-3xl font-bold mb-2">{product.name}</h1>
            </div>

            {/* Rating */}
            <div className="flex items-center gap-2 mb-6">
              <div className="flex items-center gap-1">
                {[...Array(5)].map((_, i) => (
                  <Star key={i} size={16} className="fill-accent text-accent" />
                ))}
              </div>
              <span className="text-sm text-muted-foreground">({product.reviews} reviews)</span>
            </div>

            {/* Price */}
            <div className="flex items-center gap-3 mb-6">
              <span className="text-3xl font-bold">${product.price}</span>
              <span className="text-lg text-muted-foreground line-through">${product.originalPrice}</span>
              <span className="bg-accent text-accent-foreground px-2 py-1 text-sm font-medium rounded">
                {Math.round(((product.originalPrice - product.price) / product.originalPrice) * 100)}% OFF
              </span>
            </div>

            {/* Description */}
            <p className="text-foreground/80 mb-6">{product.description}</p>

            {/* Highlights */}
            <div className="mb-6 p-4 bg-secondary rounded">
              <h3 className="font-bold mb-3">Why you'll love it:</h3>
              <ul className="space-y-2">
                {product.highlights.map((highlight, idx) => (
                  <li key={idx} className="flex items-start gap-2 text-sm">
                    <span className="text-accent mt-1">✓</span>
                    <span>{highlight}</span>
                  </li>
                ))}
              </ul>
            </div>

            {/* Color Selection */}
            <div className="mb-6">
              <label className="block text-sm font-medium mb-3">Color: {selectedColor}</label>
              <div className="flex gap-3">
                {product.colors.map((color) => (
                  <button
                    key={color}
                    onClick={() => setSelectedColor(color)}
                    className={`w-10 h-10 rounded-full border-2 transition ${
                      selectedColor === color ? "border-accent" : "border-border"
                    }`}
                    style={{
                      backgroundColor:
                        color === "Black"
                          ? "#000"
                          : color === "White"
                            ? "#fff"
                            : color === "Navy"
                              ? "#001f3f"
                              : color === "Gray"
                                ? "#999"
                                : "#f5e6d3",
                    }}
                    title={color}
                  />
                ))}
              </div>
            </div>

            {/* Size Selection */}
            <div className="mb-6">
              <label className="block text-sm font-medium mb-3">Size: {selectedSize}</label>
              <div className="grid grid-cols-4 gap-2">
                {product.sizes.map((size) => (
                  <button
                    key={size}
                    onClick={() => setSelectedSize(size)}
                    className={`py-2 px-3 border-2 rounded font-medium text-sm transition ${
                      selectedSize === size
                        ? "border-accent bg-accent text-accent-foreground"
                        : "border-border hover:border-foreground"
                    }`}
                  >
                    {size}
                  </button>
                ))}
              </div>
            </div>

            {/* Quantity */}
            <div className="mb-8 flex items-center gap-4">
              <label className="text-sm font-medium">Quantity:</label>
              <div className="flex items-center border border-border rounded">
                <button
                  onClick={() => setQuantity(Math.max(1, quantity - 1))}
                  className="px-4 py-2 hover:bg-secondary transition"
                >
                  −
                </button>
                <span className="px-6 py-2 border-l border-r border-border">{quantity}</span>
                <button onClick={() => setQuantity(quantity + 1)} className="px-4 py-2 hover:bg-secondary transition">
                  +
                </button>
              </div>
            </div>

            {/* Add to Cart Button */}
            <div className="space-y-3 mb-6">
              <button
                onClick={handleAddToCart}
                className="w-full bg-primary hover:bg-primary/90 text-primary-foreground py-3 font-bold rounded transition"
              >
                {addedToCart ? "✓ Added to Cart" : "Add to Cart"}
              </button>
              <button className="w-full border-2 border-border hover:border-foreground py-3 font-medium rounded transition flex items-center justify-center gap-2">
                <Heart size={20} />
                Add to Wishlist
              </button>
            </div>

            {/* Share */}
            <button className="flex items-center gap-2 text-sm text-muted-foreground hover:text-foreground transition">
              <Share2 size={16} />
              Share this product
            </button>

            {/* Specifications */}
            <div className="mt-8 pt-8 border-t border-border">
              <h3 className="font-bold mb-4">Specifications</h3>
              <div className="space-y-3 text-sm">
                {Object.entries(product.specifications).map(([key, value]) => (
                  <div key={key} className="flex justify-between">
                    <span className="text-muted-foreground capitalize">{key}:</span>
                    <span className="font-medium">{value as string}</span>
                  </div>
                ))}
              </div>
            </div>
          </div>
        </div>

        {/* Related Products */}
        <div className="border-t border-border pt-16">
          <h2 className="text-2xl font-bold mb-6">You Might Also Like</h2>
          <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-6">
            {[1, 2, 3, 4].map((i) => (
              <div key={i} className="group cursor-pointer">
                <div className="bg-secondary mb-3 aspect-square overflow-hidden rounded hover:scale-105 transition duration-300">
                  <img
                    src={`/related-products-display.png?height=400&width=400&query=related%20product%20${i}`}
                    alt="Related"
                    className="w-full h-full object-cover"
                  />
                </div>
                <h3 className="text-sm font-medium group-hover:text-accent transition">Related Product {i}</h3>
                <p className="text-base font-bold">$24.90</p>
              </div>
            ))}
          </div>
        </div>
      </div>
    </div>
  )
}
