"use client"

import Link from "next/link"
import { useState } from "react"
import { Menu, X, ShoppingBag, Search, User } from "lucide-react"

export default function Header() {
  const [isMenuOpen, setIsMenuOpen] = useState(false)

  return (
    <header className="sticky top-0 z-50 bg-background border-b border-border">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        {/* Top bar with search and account */}
        <div className="flex items-center justify-between h-12 text-xs text-muted-foreground border-b border-muted">
          <div className="flex-1"></div>
          <Link href="/search" className="flex items-center gap-1 hover:text-foreground transition">
            <Search size={14} />
            <span>Search</span>
          </Link>
          <Link href="/account" className="flex items-center gap-1 hover:text-foreground transition ml-6">
            <User size={14} />
            <span>Account</span>
          </Link>
        </div>

        {/* Main header */}
        <div className="flex items-center justify-between h-16 gap-4">
          {/* Logo */}
          <Link href="/" className="flex-shrink-0 font-bold text-2xl tracking-tight hover:opacity-80 transition">
            UNIQLO
          </Link>

          {/* Desktop Navigation */}
          <nav className="hidden lg:flex items-center gap-8 flex-1 px-8">
            <Link href="/men" className="text-sm font-medium hover:text-accent transition">
              Men
            </Link>
            <Link href="/women" className="text-sm font-medium hover:text-accent transition">
              Women
            </Link>
            <Link href="/kids" className="text-sm font-medium hover:text-accent transition">
              Kids
            </Link>
            <Link href="/new" className="text-sm font-medium hover:text-accent transition">
              New
            </Link>
            <Link href="/sale" className="text-sm font-medium hover:text-accent transition">
              Sale
            </Link>
          </nav>

          {/* Cart */}
          <Link href="/cart" className="flex-shrink-0 relative hover:text-accent transition">
            <ShoppingBag size={20} />
            <span className="absolute -top-2 -right-2 bg-accent text-accent-foreground text-xs rounded-full w-5 h-5 flex items-center justify-center">
              0
            </span>
          </Link>

          {/* Mobile menu toggle */}
          <button onClick={() => setIsMenuOpen(!isMenuOpen)} className="lg:hidden p-2 hover:bg-secondary transition">
            {isMenuOpen ? <X size={20} /> : <Menu size={20} />}
          </button>
        </div>

        {/* Mobile Navigation */}
        {isMenuOpen && (
          <nav className="lg:hidden py-4 border-t border-border space-y-3">
            <Link href="/men" className="block text-sm font-medium hover:text-accent transition py-2">
              Men
            </Link>
            <Link href="/women" className="block text-sm font-medium hover:text-accent transition py-2">
              Women
            </Link>
            <Link href="/kids" className="block text-sm font-medium hover:text-accent transition py-2">
              Kids
            </Link>
            <Link href="/new" className="block text-sm font-medium hover:text-accent transition py-2">
              New
            </Link>
            <Link href="/sale" className="block text-sm font-medium hover:text-accent transition py-2">
              Sale
            </Link>
          </nav>
        )}
      </div>
    </header>
  )
}
