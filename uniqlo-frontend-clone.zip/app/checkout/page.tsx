"use client"

import type React from "react"

import { useState } from "react"
import Link from "next/link"
import { ChevronLeft } from "lucide-react"

export default function CheckoutPage() {
  const [step, setStep] = useState<"shipping" | "payment" | "review">("shipping")
  const [formData, setFormData] = useState({
    firstName: "",
    lastName: "",
    email: "",
    phone: "",
    address: "",
    city: "",
    state: "",
    zip: "",
    country: "United States",
  })

  const handleInputChange = (e: React.ChangeEvent<HTMLInputElement | HTMLSelectElement>) => {
    const { name, value } = e.target
    setFormData((prev) => ({ ...prev, [name]: value }))
  }

  const cartTotal = 129.8

  return (
    <div className="min-h-screen bg-secondary">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
        <Link href="/cart" className="flex items-center gap-2 text-sm font-medium text-accent hover:underline mb-8">
          <ChevronLeft size={16} />
          Back to Cart
        </Link>

        <div className="grid grid-cols-1 lg:grid-cols-3 gap-8">
          {/* Checkout Form */}
          <div className="lg:col-span-2 bg-background rounded border border-border p-8">
            {/* Step Indicators */}
            <div className="flex items-center justify-between mb-8 pb-8 border-b border-border">
              {["shipping", "payment", "review"].map((s, idx) => (
                <div key={s} className="flex items-center gap-2">
                  <div
                    className={`w-8 h-8 rounded-full flex items-center justify-center font-bold ${
                      step === s
                        ? "bg-accent text-accent-foreground"
                        : step > s
                          ? "bg-accent text-accent-foreground"
                          : "bg-muted"
                    }`}
                  >
                    {idx + 1}
                  </div>
                  <span className="text-sm font-medium capitalize hidden sm:inline">{s}</span>
                  {idx < 2 && <div className="w-8 h-0.5 bg-border mx-2" />}
                </div>
              ))}
            </div>

            {/* Shipping Form */}
            {step === "shipping" && (
              <div className="space-y-4">
                <h2 className="text-2xl font-bold mb-6">Shipping Address</h2>
                <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                  <input
                    type="text"
                    name="firstName"
                    placeholder="First Name"
                    value={formData.firstName}
                    onChange={handleInputChange}
                    className="px-4 py-3 border border-input rounded bg-secondary focus:outline-none focus:ring-2 focus:ring-accent"
                  />
                  <input
                    type="text"
                    name="lastName"
                    placeholder="Last Name"
                    value={formData.lastName}
                    onChange={handleInputChange}
                    className="px-4 py-3 border border-input rounded bg-secondary focus:outline-none focus:ring-2 focus:ring-accent"
                  />
                </div>
                <input
                  type="email"
                  name="email"
                  placeholder="Email Address"
                  value={formData.email}
                  onChange={handleInputChange}
                  className="w-full px-4 py-3 border border-input rounded bg-secondary focus:outline-none focus:ring-2 focus:ring-accent"
                />
                <input
                  type="tel"
                  name="phone"
                  placeholder="Phone Number"
                  value={formData.phone}
                  onChange={handleInputChange}
                  className="w-full px-4 py-3 border border-input rounded bg-secondary focus:outline-none focus:ring-2 focus:ring-accent"
                />
                <input
                  type="text"
                  name="address"
                  placeholder="Street Address"
                  value={formData.address}
                  onChange={handleInputChange}
                  className="w-full px-4 py-3 border border-input rounded bg-secondary focus:outline-none focus:ring-2 focus:ring-accent"
                />
                <div className="grid grid-cols-2 gap-4">
                  <input
                    type="text"
                    name="city"
                    placeholder="City"
                    value={formData.city}
                    onChange={handleInputChange}
                    className="px-4 py-3 border border-input rounded bg-secondary focus:outline-none focus:ring-2 focus:ring-accent"
                  />
                  <input
                    type="text"
                    name="state"
                    placeholder="State"
                    value={formData.state}
                    onChange={handleInputChange}
                    className="px-4 py-3 border border-input rounded bg-secondary focus:outline-none focus:ring-2 focus:ring-accent"
                  />
                </div>
                <input
                  type="text"
                  name="zip"
                  placeholder="ZIP Code"
                  value={formData.zip}
                  onChange={handleInputChange}
                  className="w-full px-4 py-3 border border-input rounded bg-secondary focus:outline-none focus:ring-2 focus:ring-accent"
                />
                <button
                  onClick={() => setStep("payment")}
                  className="w-full mt-6 bg-primary text-primary-foreground py-3 rounded font-bold hover:opacity-90 transition"
                >
                  Continue to Payment
                </button>
              </div>
            )}

            {/* Payment Form */}
            {step === "payment" && (
              <div className="space-y-4">
                <h2 className="text-2xl font-bold mb-6">Payment Information</h2>
                <input
                  type="text"
                  placeholder="Full Name"
                  className="w-full px-4 py-3 border border-input rounded bg-secondary focus:outline-none focus:ring-2 focus:ring-accent"
                />
                <input
                  type="text"
                  placeholder="Card Number"
                  className="w-full px-4 py-3 border border-input rounded bg-secondary focus:outline-none focus:ring-2 focus:ring-accent"
                />
                <div className="grid grid-cols-2 gap-4">
                  <input
                    type="text"
                    placeholder="MM/YY"
                    className="px-4 py-3 border border-input rounded bg-secondary focus:outline-none focus:ring-2 focus:ring-accent"
                  />
                  <input
                    type="text"
                    placeholder="CVV"
                    className="px-4 py-3 border border-input rounded bg-secondary focus:outline-none focus:ring-2 focus:ring-accent"
                  />
                </div>
                <div className="flex gap-2 pt-4">
                  <button
                    onClick={() => setStep("shipping")}
                    className="flex-1 border-2 border-foreground py-3 rounded font-medium hover:bg-secondary transition"
                  >
                    Back
                  </button>
                  <button
                    onClick={() => setStep("review")}
                    className="flex-1 bg-primary text-primary-foreground py-3 rounded font-bold hover:opacity-90 transition"
                  >
                    Review Order
                  </button>
                </div>
              </div>
            )}

            {/* Order Review */}
            {step === "review" && (
              <div className="space-y-6">
                <h2 className="text-2xl font-bold mb-6">Review Your Order</h2>

                <div className="p-4 bg-secondary rounded border border-border">
                  <h3 className="font-bold mb-3">Shipping To:</h3>
                  <p>
                    {formData.firstName} {formData.lastName}
                  </p>
                  <p>{formData.address}</p>
                  <p>
                    {formData.city}, {formData.state} {formData.zip}
                  </p>
                </div>

                <button
                  onClick={() => {
                    alert("Order placed successfully!")
                  }}
                  className="w-full bg-accent text-accent-foreground py-4 rounded font-bold text-lg hover:opacity-90 transition"
                >
                  Place Order
                </button>
              </div>
            )}
          </div>

          {/* Order Summary Sidebar */}
          <div className="lg:col-span-1">
            <div className="bg-background rounded border border-border p-6 sticky top-20 space-y-4">
              <h2 className="text-lg font-bold">Order Summary</h2>

              <div className="space-y-3 border-b border-border pb-4">
                <div className="space-y-2">
                  <div className="flex justify-between text-sm">
                    <span>Premium Crewneck T-Shirt (x2)</span>
                    <span>$59.80</span>
                  </div>
                  <div className="flex justify-between text-sm">
                    <span>Cotton Linen Blend Pants (x1)</span>
                    <span>$49.90</span>
                  </div>
                </div>
              </div>

              <div className="space-y-2 text-sm border-b border-border pb-4">
                <div className="flex justify-between">
                  <span>Subtotal</span>
                  <span>$109.70</span>
                </div>
                <div className="flex justify-between">
                  <span>Shipping</span>
                  <span>$10.00</span>
                </div>
                <div className="flex justify-between">
                  <span>Tax</span>
                  <span>$9.50</span>
                </div>
              </div>

              <div className="flex justify-between text-lg font-bold">
                <span>Total</span>
                <span>${cartTotal.toFixed(2)}</span>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  )
}
