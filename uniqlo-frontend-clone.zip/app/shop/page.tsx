"use client"

import { useState, useMemo } from "react"
import ProductCard from "@/components/product-card"

export default function ShopPage() {
  const [selectedCategory, setSelectedCategory] = useState<string | null>(null)
  const [selectedSize, setSelectedSize] = useState<string | null>(null)
  const [selectedPrice, setSelectedPrice] = useState<string | null>(null)
  const [sortBy, setSortBy] = useState("featured")

  // Mock products
  const allProducts = [
    { id: "1", name: "Ultra Soft Crewneck T-Shirt", price: 19.9, category: "Men", size: "All", rating: 4.8 },
    { id: "2", name: "Heattech Base Layer", price: 29.9, category: "Men", size: "All", rating: 4.9 },
    { id: "3", name: "Rayon Long-Sleeve Shirt", price: 34.9, category: "Women", size: "All", rating: 4.7 },
    { id: "4", name: "Cotton Linen Blend Pants", price: 49.9, category: "Women", size: "All", rating: 4.6 },
    { id: "5", name: "Kids Lightweight Down Jacket", price: 59.9, category: "Kids", size: "All", rating: 4.8 },
    { id: "6", name: "AIRism Cotton Shorts", price: 24.9, category: "Men", size: "All", rating: 4.7 },
    { id: "7", name: "Wool Blend Sweater", price: 39.9, category: "Women", size: "All", rating: 4.9 },
    { id: "8", name: "Seamless Layering Tank", price: 14.9, category: "Women", size: "All", rating: 4.6 },
    { id: "9", name: "Stretch Denim Jeans", price: 59.9, category: "Men", size: "All", rating: 4.8 },
    { id: "10", name: "Silk Blend Blouse", price: 44.9, category: "Women", size: "All", rating: 4.7 },
    { id: "11", name: "Lightweight Puffer Jacket", price: 79.9, category: "Men", size: "All", rating: 4.9 },
    { id: "12", name: "Merino Wool Socks", price: 9.9, category: "Kids", size: "All", rating: 4.5 },
  ]

  const filteredAndSortedProducts = useMemo(() => {
    let result = allProducts

    // Filter by category
    if (selectedCategory) {
      result = result.filter((p) => p.category === selectedCategory)
    }

    // Filter by price
    if (selectedPrice) {
      if (selectedPrice === "under50") result = result.filter((p) => p.price < 50)
      if (selectedPrice === "50to100") result = result.filter((p) => p.price >= 50 && p.price <= 100)
      if (selectedPrice === "over100") result = result.filter((p) => p.price > 100)
    }

    // Sort
    if (sortBy === "price-low") result = result.sort((a, b) => a.price - b.price)
    if (sortBy === "price-high") result = result.sort((a, b) => b.price - a.price)
    if (sortBy === "rating") result = result.sort((a, b) => b.rating - a.rating)

    return result
  }, [selectedCategory, selectedPrice, sortBy])

  return (
    <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
      <h1 className="text-4xl font-bold mb-8">Shop All Products</h1>

      <div className="grid grid-cols-1 lg:grid-cols-4 gap-8">
        {/* Sidebar Filters */}
        <aside className="lg:col-span-1">
          {/* Category Filter */}
          <div className="mb-8 pb-8 border-b border-border">
            <h3 className="font-bold text-lg mb-4">Category</h3>
            <div className="space-y-2">
              {["Men", "Women", "Kids"].map((cat) => (
                <label key={cat} className="flex items-center gap-2 cursor-pointer">
                  <input
                    type="radio"
                    name="category"
                    value={cat}
                    checked={selectedCategory === cat}
                    onChange={(e) => setSelectedCategory(e.target.checked ? cat : null)}
                    className="w-4 h-4"
                  />
                  <span className="text-sm">{cat}</span>
                </label>
              ))}
            </div>
          </div>

          {/* Price Filter */}
          <div className="mb-8 pb-8 border-b border-border">
            <h3 className="font-bold text-lg mb-4">Price</h3>
            <div className="space-y-2">
              {[
                { value: "under50", label: "Under $50" },
                { value: "50to100", label: "$50 - $100" },
                { value: "over100", label: "Over $100" },
              ].map((price) => (
                <label key={price.value} className="flex items-center gap-2 cursor-pointer">
                  <input
                    type="radio"
                    name="price"
                    value={price.value}
                    checked={selectedPrice === price.value}
                    onChange={(e) => setSelectedPrice(e.target.checked ? price.value : null)}
                    className="w-4 h-4"
                  />
                  <span className="text-sm">{price.label}</span>
                </label>
              ))}
            </div>
          </div>

          {/* Clear Filters */}
          <button
            onClick={() => {
              setSelectedCategory(null)
              setSelectedPrice(null)
            }}
            className="w-full px-4 py-2 bg-secondary hover:bg-secondary/80 rounded font-medium transition text-sm"
          >
            Clear Filters
          </button>
        </aside>

        {/* Products Grid */}
        <main className="lg:col-span-3">
          {/* Sort Options */}
          <div className="flex items-center justify-between mb-6 pb-6 border-b border-border">
            <p className="text-sm text-muted-foreground">Showing {filteredAndSortedProducts.length} products</p>
            <div className="flex items-center gap-2">
              <label htmlFor="sort" className="text-sm font-medium">
                Sort by:
              </label>
              <select
                id="sort"
                value={sortBy}
                onChange={(e) => setSortBy(e.target.value)}
                className="px-3 py-2 border border-input rounded text-sm bg-background"
              >
                <option value="featured">Featured</option>
                <option value="price-low">Price: Low to High</option>
                <option value="price-high">Price: High to Low</option>
                <option value="rating">Highest Rated</option>
              </select>
            </div>
          </div>

          {/* Products Grid */}
          <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-6">
            {filteredAndSortedProducts.map((product) => (
              <ProductCard
                key={product.id}
                id={product.id}
                name={product.name}
                price={product.price}
                image={`/placeholder.svg?height=400&width=400&query=uniqlo%20${product.name.replace(/ /g, "%20")}`}
                category={product.category}
                rating={product.rating}
              />
            ))}
          </div>

          {filteredAndSortedProducts.length === 0 && (
            <div className="text-center py-12">
              <p className="text-muted-foreground">No products found. Try adjusting your filters.</p>
            </div>
          )}
        </main>
      </div>
    </div>
  )
}
