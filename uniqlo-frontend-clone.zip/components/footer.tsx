import Link from "next/link"
import { Facebook, Twitter, Instagram } from "lucide-react"

export default function Footer() {
  return (
    <footer className="bg-primary text-primary-foreground border-t border-border">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-12">
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-8 mb-8">
          {/* Customer Service */}
          <div>
            <h3 className="font-bold mb-4">Customer Service</h3>
            <ul className="space-y-2 text-sm">
              <li>
                <Link href="#" className="hover:underline">
                  Contact Us
                </Link>
              </li>
              <li>
                <Link href="#" className="hover:underline">
                  FAQ
                </Link>
              </li>
              <li>
                <Link href="#" className="hover:underline">
                  Shipping Info
                </Link>
              </li>
              <li>
                <Link href="#" className="hover:underline">
                  Returns
                </Link>
              </li>
              <li>
                <Link href="#" className="hover:underline">
                  Size Guide
                </Link>
              </li>
            </ul>
          </div>

          {/* Company */}
          <div>
            <h3 className="font-bold mb-4">Company</h3>
            <ul className="space-y-2 text-sm">
              <li>
                <Link href="#" className="hover:underline">
                  About Us
                </Link>
              </li>
              <li>
                <Link href="#" className="hover:underline">
                  Careers
                </Link>
              </li>
              <li>
                <Link href="#" className="hover:underline">
                  Sustainability
                </Link>
              </li>
              <li>
                <Link href="#" className="hover:underline">
                  Press
                </Link>
              </li>
            </ul>
          </div>

          {/* Store Locator */}
          <div>
            <h3 className="font-bold mb-4">Stores</h3>
            <ul className="space-y-2 text-sm">
              <li>
                <Link href="#" className="hover:underline">
                  Store Locator
                </Link>
              </li>
              <li>
                <Link href="#" className="hover:underline">
                  Find a Store
                </Link>
              </li>
              <li>
                <Link href="#" className="hover:underline">
                  Virtual Shopping
                </Link>
              </li>
              <li>
                <Link href="#" className="hover:underline">
                  In-Store Events
                </Link>
              </li>
            </ul>
          </div>

          {/* Newsletter */}
          <div>
            <h3 className="font-bold mb-4">Newsletter</h3>
            <p className="text-sm mb-3">Subscribe to get special offers and the latest updates.</p>
            <input
              type="email"
              placeholder="Enter your email"
              className="w-full px-3 py-2 bg-primary-foreground text-primary rounded text-sm mb-2"
            />
            <button className="w-full px-3 py-2 bg-secondary text-secondary-foreground rounded text-sm font-medium hover:opacity-90 transition">
              Subscribe
            </button>
          </div>
        </div>

        {/* Social Media */}
        <div className="flex justify-center gap-4 mb-8 pb-8 border-t border-primary-foreground/20">
          <Link href="#" className="hover:opacity-80 transition">
            <Facebook size={20} />
          </Link>
          <Link href="#" className="hover:opacity-80 transition">
            <Twitter size={20} />
          </Link>
          <Link href="#" className="hover:opacity-80 transition">
            <Instagram size={20} />
          </Link>
        </div>

        {/* Bottom info */}
        <div className="flex flex-col md:flex-row justify-between items-center gap-4 text-xs text-primary-foreground/70 border-t border-primary-foreground/20 pt-8">
          <div className="flex gap-4">
            <Link href="#" className="hover:underline">
              Privacy Policy
            </Link>
            <Link href="#" className="hover:underline">
              Terms of Service
            </Link>
            <Link href="#" className="hover:underline">
              Cookies
            </Link>
          </div>
          <p>&copy; 2025 UNIQLO. All rights reserved.</p>
        </div>
      </div>
    </footer>
  )
}
