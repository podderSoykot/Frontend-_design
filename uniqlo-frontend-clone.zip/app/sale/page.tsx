"use client"

export default function SalePage() {
  const saleProducts = [
    {
      id: "1",
      name: "Ultra Soft Crewneck T-Shirt",
      price: 14.9,
      originalPrice: 29.9,
      category: "Men",
      rating: 4.8,
      discount: 50,
    },
    {
      id: "2",
      name: "Wool Blend Sweater",
      price: 29.9,
      originalPrice: 59.9,
      category: "Women",
      rating: 4.9,
      discount: 50,
    },
    {
      id: "3",
      name: "Cotton Linen Blend Pants",
      price: 34.9,
      originalPrice: 49.9,
      category: "Women",
      rating: 4.6,
      discount: 30,
    },
    {
      id: "4",
      name: "AIRism Cotton Shorts",
      price: 16.9,
      originalPrice: 24.9,
      category: "Men",
      rating: 4.7,
      discount: 32,
    },
    {
      id: "5",
      name: "Stretch Denim Jeans",
      price: 39.9,
      originalPrice: 59.9,
      category: "Men",
      rating: 4.8,
      discount: 33,
    },
    {
      id: "6",
      name: "Silk Blend Blouse",
      price: 29.9,
      originalPrice: 44.9,
      category: "Women",
      rating: 4.7,
      discount: 33,
    },
    {
      id: "7",
      name: "Rayon Long-Sleeve Shirt",
      price: 24.9,
      originalPrice: 34.9,
      category: "Women",
      rating: 4.7,
      discount: 29,
    },
    {
      id: "8",
      name: "Seamless Layering Tank",
      price: 9.9,
      originalPrice: 14.9,
      category: "Women",
      rating: 4.6,
      discount: 34,
    },
  ]

  return (
    <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
      <h1 className="text-4xl font-bold mb-4">Sale</h1>
      <p className="text-lg text-muted-foreground mb-8">Save big on our favorite items. Limited time offers!</p>

      <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-6">
        {saleProducts.map((product) => (
          <div key={product.id} className="group cursor-pointer">
            <div className="relative overflow-hidden bg-secondary mb-3 aspect-square">
              <img
                src={`/sale-.jpg?height=400&width=400&query=sale%20${product.name.replace(/ /g, "%20")}`}
                alt={product.name}
                className="w-full h-full object-cover group-hover:scale-105 transition duration-300"
              />
              <div className="absolute top-3 right-3 bg-accent text-accent-foreground px-2 py-1 text-xs font-bold rounded">
                -{product.discount}%
              </div>
            </div>
            <div className="space-y-1">
              <p className="text-xs text-muted-foreground">{product.category}</p>
              <h3 className="text-sm font-medium line-clamp-2 group-hover:text-accent transition">{product.name}</h3>
              <div className="flex items-center justify-between gap-2">
                <div className="flex items-baseline gap-2">
                  <p className="text-base font-bold">${product.price.toFixed(2)}</p>
                  <p className="text-sm text-muted-foreground line-through">${product.originalPrice.toFixed(2)}</p>
                </div>
                {product.rating && <span className="text-xs text-muted-foreground">★ {product.rating}</span>}
              </div>
            </div>
          </div>
        ))}
      </div>
    </div>
  )
}
